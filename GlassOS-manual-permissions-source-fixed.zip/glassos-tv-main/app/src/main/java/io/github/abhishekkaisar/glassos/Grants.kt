package io.github.abhishekkaisar.glassos

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings

/**
 * Tracks optional permissions used by GlassOS. Permissions are granted by the user in Android settings
 * or manually with ADB from a trusted computer. GlassOS never connects to the TV's ADB service.
 */
object Grants {
    class Grant(val title: String, val why: String, val isGranted: (Context) -> Boolean)

    val ALL = listOf(
        Grant("Usage access", "Comes back after the Home button", { HomeWatcher.hasAccess(it) }),
        Grant("Display over other apps", "Shows the home at once after Home", { canDrawOverlays(it) }),
        Grant("Notification access", "Now Playing and Do Not Disturb", { listenerEnabled(it) }),
        Grant("Device admin", "Sleep and the sleep timer", { Power.adminActive(it) }),
        Grant("Storage", "Your profile photo and own backgrounds", { storage(it) })
    )

    fun canDrawOverlays(ctx: Context) = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(ctx)

    fun storage(ctx: Context) = Build.VERSION.SDK_INT < 23 ||
        ctx.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    fun listenerEnabled(ctx: Context): Boolean = try {
        val comp = MediaListener.component(ctx)
        if (Build.VERSION.SDK_INT >= 27 &&
            ctx.getSystemService(android.app.NotificationManager::class.java).isNotificationListenerAccessGranted(comp)) true
        else {
            val v = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners") ?: ""
            v.split(':').any { it == comp.flattenToString() || it == comp.flattenToShortString() }
        }
    } catch (e: Throwable) { false }

    fun allGranted(ctx: Context) = ALL.all { it.isGranted(ctx) }
}
